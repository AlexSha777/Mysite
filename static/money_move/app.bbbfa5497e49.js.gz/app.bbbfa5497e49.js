function do_something(value_1) {
	
	document.getElementById("field2").value = value_1;
	alert(value_1);
}
            